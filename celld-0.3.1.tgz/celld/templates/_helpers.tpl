{{- define "celld.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "celld.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "celld.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "celld.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "celld.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "celld.selectorLabels" -}}
app.kubernetes.io/name: {{ include "celld.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "celld.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "celld.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "celld.azurite.fullname" -}}
{{- printf "%s-azurite" (include "celld.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "celld.azurite.secretName" -}}
{{- printf "%s-azurite" (include "celld.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "celld.azurite.connectionString" -}}
DefaultEndpointsProtocol=http;AccountName={{ .Values.azurite.accountName }};AccountKey={{ .Values.azurite.accountKey }};BlobEndpoint=http://{{ include "celld.azurite.fullname" . }}:{{ .Values.azurite.blobPort }}/{{ .Values.azurite.accountName }};
{{- end -}}
